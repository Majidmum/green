import Link from "next/link";
import { Leaf } from "lucide-react";

export default function AuthLayout({ children }) {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-brand-light/70 to-brand-cream px-4 py-10">
      <Link href="/" className="mb-8 flex items-center gap-2 font-display text-2xl font-bold text-brand-dark">
        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-brand text-white"><Leaf size={20} /></span>
        GREEN GARDEN
      </Link>
      <main className="card w-full max-w-md p-8">{children}</main>
      <Link href="/" className="mt-6 text-sm text-brand-ink/60 hover:text-brand">← Вернуться в магазин</Link>
    </div>
  );
}
